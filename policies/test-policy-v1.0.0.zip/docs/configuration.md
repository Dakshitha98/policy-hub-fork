# Configuration

## Parameters

- `enabled`: Enable or disable the policy (default: true)
