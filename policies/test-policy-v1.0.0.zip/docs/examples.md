# Examples

## Basic Usage

```yaml
apiVersion: policy/v1
kind: Policy
metadata:
  name: test-policy
spec:
  rules:
    - name: test-rule
      condition: "true"
      action: allow
```
