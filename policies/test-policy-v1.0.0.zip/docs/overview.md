# Test Policy Overview

This is a test policy for validation purposes.

## Purpose

Demonstrates policy structure validation.
